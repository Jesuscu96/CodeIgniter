<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\Conciertos;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', [Conciertos::class, 'index']);
$routes->get('conciertos', [Conciertos::class, 'index']);
$routes->get('(:segment)', [Pages::class, 'view']);
$routes->get('conciertos/(:segment)', [Conciertos::class, 'show']);

