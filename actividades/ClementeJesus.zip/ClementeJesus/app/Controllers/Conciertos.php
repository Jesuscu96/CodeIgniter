<?php

namespace App\Controllers;
use CodeIgniter\Exceptions\PageNotFoundException;


use App\Models\ConciertosModel;
//use App\Models\CategoryModel;

class Conciertos extends BaseController
{
    public function index()
    {
        $model = model(ConciertosModel::class);

        $data = [
            'conciertos_list' => $model->getConciertos(),
            'nombre'     => 'Conciertos archive',
        ];

        return view('templates/header', $data)
                . view('conciertos/index')
                . view('templates/footer');
    }
    
    public function show(?string $slug = null)
    {
        $model = model(ConciertosModel::class);

        $data['conciertos_valencia'] = $model->getConciertos($slug);
        
        if ($data['conciertos_valencia'] === null) {
            throw new PageNotFoundException('Cannot find the concierto item: ' . $slug);
        }

        $data['nombre_concirto'] = $data['concierto_valencia']['nombre_concierto'];

        return view('templates/header', $data)
            . view('conciertos/view')
            . view('templates/footer');
    }

    
}
   