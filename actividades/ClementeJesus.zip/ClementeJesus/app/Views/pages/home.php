<section>
    <h1><?=esc($title)?></h1>
    <h2>Página Inicio</h2>
</section>
