<section>

    <h2><?= esc($title) ?></h2>
    

    <?php if ($conciertos_list !== []): ?>

        <?php foreach ($conciertos_list as $conciertos_item): ?>

            <h3><?= esc($conciertos_item['nombre_concierto']) ?></h3>

            <div class="main">
                <?= esc($conciertos_item['lugar']) ?>
            </div>
            <div class="main">
                Fecha: <b><?= esc($conciertos_item['fecha']) ?></b>
            </div>
            <div class="main">
                Fecha: <b><?= esc($conciertos_item['precio']) ?></b>
            </div>
            <p>
                <a href="<?= base_url('concierto/'.$conciertos_item['slug']) ?>">View concierto</a>
            </p>


        <?php endforeach ?>

    <?php else: ?>

        <h3>No Conciertos</h3>

        <p>Unable to find any conciertos for you.</p>

    <?php endif ?>
</section>
