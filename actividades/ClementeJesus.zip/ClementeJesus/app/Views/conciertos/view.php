<section>
    <h2><?= esc($news['nombre_concierto']) ?></h2>
    <p><?= esc($news['lugar']) ?></p>
    <p><?= esc($news['fecha']) ?></p>
    <p><?= esc($news['precio']) ?></p>
    <p><a href="<?= base_url('concierto') ?>">Volver</a></p>
</section>