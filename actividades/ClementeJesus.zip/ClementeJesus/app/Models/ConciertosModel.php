<?php

namespace App\Models;

use CodeIgniter\Model;

class NewsModel extends Model
{
    protected $table = 'conciertos_valencia';
    protected $allowedFields = ['nombre_concierto','slug','lugar','fecha', "precio"];

     /**
     * @param false|string $slug
     *
     * @return array|null
     */
    public function getConciertos($slug = false)
    {
        if ($slug === false) {
            $sql = $this->select('conciertos_valencia.*');
            
            $sql = $this->findAll();
            return $sql;
        }

        $sql = $this->select('conciertos_valencia.*');
        $sql = $this->where(['slug' => $slug]);
        $sql = $this->first();
        return $sql;
    }
}