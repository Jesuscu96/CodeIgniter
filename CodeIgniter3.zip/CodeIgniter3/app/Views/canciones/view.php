<section>
    <h2>Título : <?= esc($canciones['titulo']) ?></h2>
    <p>Artista :<?= esc($canciones['nombre']) ?></p>
    <a href="<?= base_url('canciones') ?>">Go to canciones</a>
</section>